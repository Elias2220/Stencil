# Stencil

CRUD EN STENCIL

Utilice la etiqueta (<crud-component></crud-component>)

