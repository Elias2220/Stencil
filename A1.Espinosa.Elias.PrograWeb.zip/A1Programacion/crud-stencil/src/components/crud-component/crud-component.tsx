import { Component, Host, State, h } from '@stencil/core';

@Component({
  tag: 'crud-component',
  styleUrl: 'crud-component.css',
  shadow: true,
})



export class CrudComponent {
  @State() limpiezas: any[] = [];
  @State() limpieza = {
      "id": '',
      "actividad": "",
      "responsable": "",
      "estado": "" 
  }

  baseUrl = 'http://localhost:9000/api';
  
//devolver acrividades
async fetchLimpiezas(){
  try{
    const response = await fetch(this.baseUrl);
    const data = await response.json();
    this.limpiezas = data; 
  } catch (error){
    console.log("Error fetching Limpieza ",error);
  }
}

async createLimpieza(){
  try {
    await fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(this.limpieza)
    });
    this.fetchLimpiezas();
    this.resetForm();
  } catch (error) {
    console.log("Error creating Limpieza ",error);
  }
}

async updateLimpieza(id){
  try {
    await fetch(`${this.baseUrl}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(this.limpieza)
    });
    this.fetchLimpiezas();
    this.resetForm();
  } catch(error) {
    console.log("Error updating limpieza ", error);
  }
}

async deleteLimpieza(id){
  try {
    await fetch(`${this.baseUrl}/${id}`,{
      method: 'DELETE'
    });
    this.fetchLimpiezas();
  } catch (error) {
    console.log("Error deleteing limpieza ", error);
  }
}

componentWillLoad(){
  this.fetchLimpiezas();
}

handleInputChange(event){
  const {name, value} = event.target;
  this.limpieza={...this.limpieza, [name]: value };
}

resetForm(){
  this.limpieza = {
      "id": '',
      "actividad": "",
      "responsable": "",
      "estado": ""
  }
}

  render() {
    return (
      <div>
        <hi>Listado de limpieza</hi>
        <form 
          onSubmit={(e)=>{
            e.preventDefault();
            this.limpieza.id? this.updateLimpieza(this.limpieza.id) : this.createLimpieza()
          }}    
        >
          <input type="text"
            name='actividad'
            value={this.limpieza.actividad}
            placeholder='Actividad'
            onInput={(event) => this.handleInputChange(event)}
          />

            <input type="text"
            name='responsable'
            value={this.limpieza.responsable}
            placeholder='Responsable'
            onInput={(event) => this.handleInputChange(event)}
          />

          <input type="text"
            name='estado'
            value={this.limpieza.estado}
            placeholder='Estado'
            onInput={(event) => this.handleInputChange(event)}
          />
          <button type='submit'>{this.limpieza.id? 'Actualizar' : 'Crear'} Limpieza</button>
        </form>

        <table>
          <thead>
            <tr>
              <th>Id</th>
              <th>actividad</th>
              <th>responsable</th>
              <th>estado</th>
              <th>acciones</th>
            </tr> 
          </thead>
          <tbody>
            {this.limpiezas.map((limpieza) => (
              <tr>
                <td>{limpieza.id}</td>
                <td>{limpieza.actividad}</td>
                <td>{limpieza.responsable}</td>
                <td>{limpieza.estado}</td>
                <td>
                  <button onClick={()=>(this.limpieza= limpieza)}>Actualizar</button>
                  <button onClick={()=>(this.deleteLimpieza(limpieza.id))}>Eliminar</button>
                </td>
              </tr>


            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
