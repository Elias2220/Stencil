//Se llama los comandos para conexion al express y mysql
const express = require('express')
const routes = express.Router()
//Lectura de las actividades
routes.get('/', (req, res)=>{
    req.getConnection((err,conn)=>{
        if(err) return res.send.apply(err)

            conn.query('SELECT * FROM limpieza', (err, rows)=>{
                if(err) return res.send(err)

                    res.json(rows)
            })
    })
})
//Agregar limpieza
routes.post('/', (req, res)=>{
    req.getConnection((err,conn)=>{
        if(err) return res.send.apply(err)
            conn.query('INSERT INTO limpieza set ?', [req.body], (err, rows)=>{
                if(err) return res.send(err)

                res.send('tarea insertada')
            })
    })
})
//Eliminar limpieza
routes.delete('/:id', (req, res)=>{
    req.getConnection((err,conn)=>{
        if(err) return res.send.apply(err)
            conn.query('DELETE FROM limpieza WHERE id = ?', [req.params.id], (err, rows)=>{
                if(err) return res.send(err)

                res.send('tarea eliminada')
            })
    })
})
//Actualizar limpieza
routes.put('/:id', (req, res)=>{
    req.getConnection((err,conn)=>{
        if(err) return res.send.apply(err)
            conn.query('UPDATE limpieza set ? WHERE id = ?', [req.body, req.params.id], (err, rows)=>{
                if(err) return res.send(err)

                res.send('tarea actualizada')
            })
    })
})

module.exports = routes